export const apiCompatibilityParams: any;
