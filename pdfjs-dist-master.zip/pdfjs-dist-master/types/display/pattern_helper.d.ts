export function getShadingPatternFromIR(raw: any): any;
/**
 * @type {any}
 */
export const TilingPattern: any;
