export let NodeCanvasFactory: {
    new (): {};
};
export let NodeCMapReaderFactory: {
    new (): {};
};
